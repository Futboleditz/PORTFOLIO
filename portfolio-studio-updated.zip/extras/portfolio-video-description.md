# Screen recording: reference portfolio vs. my portfolio

**How to use this file:** paste it into another AI model together with your code (or a link to the repo). It describes what a 42-second desktop screen recording shows, then lists the differences and what to build or fix.

**Recording facts:** 1322x604 px desktop browser window, about 42.5 s, 30 fps. Timestamps below are approximate (sampled every 2 s, plus extra frames around transitions). Only the visuals were analysed, not the audio.

**Two parts:**
- **Part A (0:00 to about 0:30): the reference site (the design I want).** The browser status bar shows `therishithakor.com/#works`.
- **Part B (about 0:33 to 0:42): my site (Arghya's portfolio), which is built in the same style but is missing things.**

---

## Global design language (the reference, which my site copies)

- Warm off-white / greige palette, near-black (charcoal) accents, soft large shadows.
- Page content sits inside very large rounded containers (huge corner radius).
- Pill-shaped buttons and chips everywhere. Primary buttons are black pills; secondary ones are outlined or grey.
- Big, bold, tightly tracked grotesk sans-serif headings. Small uppercase monospace labels (for example "IOS APP · FINANCE").
- A physical-looking "hallway of arched doors" illustration: beige wall, white arch frames, spotlight glow above each door, white baseboard, pale floor with a peach/orange gradient glow at the lower left, and brass nameplates, lever handles and keyholes.
- Fixed header with frosted/translucent strip and a hairline border. Floating round dark "scroll to top" button at the bottom right with a circular progress ring.

---

## Part A: Reference site, frame by frame

**0:00.** Bottom of a web-project page inside a big rounded container. Fixed header: grey pill "← Back to the doors" (left) and outlined pill "≡ Menu" (right). Visible content: tag pills "Content page", "Data tables", "SEO"; a black pill button "Visit live site ↗"; on the right a desktop-monitor mockup (silver stand) with tiny text on its screen. The card is cream with rounded bottom corners and a soft shadow. Below it is a near-black footer block with a rounded top-left corner and the label "● AVAILABLE FOR NEW WORK" (green dot). Scroll-to-top button with ring at the bottom right.

**0:02.** The same screen is washed out toward white: an exit fade has started (after clicking "Back to the doors").

**0:03.** Whole viewport is blank off-white (mid-transition).

**0:03.5.** Extreme close-up of a navy door with a brass "WEB DEVELOPER" plate, handle and keyhole, with the white arch frame at the left. The camera is zooming out from a door, which is the return animation.

**0:04.** The hall of doors. Heading "Magic happens behind the doors" (cut off at the top). Four arched doors evenly spaced:
1. navy, "WEB DEVELOPER" (currently swung open in perspective, showing bright white light behind it);
2. dark plum, "APP DEVELOPER";
3. sage green, "UI/UX DESIGNER";
4. rust orange, "GRAPHIC DESIGNER".

Peach gradient on the floor at the lower left, a small "My story" label at the bottom left, scroll-to-top button at the bottom right.

**0:04 to 0:06.** Idle. The first door stays ajar. The header is now "≡ MENU" (left pill) and "Local time 11:18am · 8 November, 2026" (right pill).

**0:06 to 0:06.5 (hover).** The cursor moves over door 2. Door 2 swings partly open. A dark rounded tooltip "Click to enter" follows the cursor. The other three doors fade to ghosted, desaturated versions, and door 1 closes. A text panel appears to the right of door 2: title "App Development", a small uppercase monospace line "FROM THE FIRST IDEA TO THE APP STORE", and a five-item checklist with round check icons (product scoping and user flows; interface design; cross-platform development; device testing and store launch; analytics, monitoring and updates). The panel overlaps door 3.

**0:07 to 0:08.** Door 2 swings wider open, showing white light.

**0:08 to 0:09.** The screen goes blank off-white: page transition into the category page.

**0:10.** Category page "App Development". Rounded container; fixed pills "← Back to the doors" and "≡ Menu". Very large bold H1 "App Development" with a short intro paragraph under it (iOS apps and games built end to end). Below, a cream card begins: blue app icon with a white ₹ symbol, label "IOS APP · FINANCE", the title "Expense Tracker", and an iPhone mockup on the right. A dark cookie banner is centred at the bottom: asks to count the visit with Google Analytics (sets cookies), with an outlined "No thanks" button and a light "Allow" button.

**0:12.** Scrolling. The H1 is being swallowed under the header and only a few small black squares remain visible where the title was (this looks like a title mask or animation artifact). The card shows the icon, label, "Expense Tracker", and the start of a description ("Spending is grouped into expense books..."). Phone screen: dark "Expense Tracker" UI, playing as a video. Cursor over "No thanks".

**0:14.** Banner dismissed. Header strip now shows a hairline border; the H1 scrolls behind it. Card subtitle: "Personal finance, organised into books". Phone screen shows a "New Expense Book" form (Cancel / Create, book title field, category icon picker).

**0:16.** Sticky stacking cards: the Expense Tracker card has shrunk slightly and turned grey/dim, while a new cream card slides up from the bottom and covers its lower part. Phone screen: "Personal Expenses" with total balance +₹2,994.70, spent ₹205.30, income +₹3,200.00, budget ₹1,500, and a budget bar at 13%. The scroll-to-top button has appeared.

**0:18.** Second card "Secret Vault" is in front; the first card peeks out as a thin grey strip at the top behind it. The layout is mirrored: phone on the LEFT (slightly tilted in 3D), text on the right. Olive-green calculator-style app icon, label "IOS APP · PRIVACY", title "Secret Vault", tagline "A photo vault disguised as a calculator", then a short description of the hidden-vault behaviour. Phone screen: "Password Setup", "Step 1: Set Password Equation", calculator keypad. The card is still fading in (slightly translucent).

**0:20.** A third card slides up over Secret Vault, which dims and shrinks. The incoming card's content (icon, label, phone with a pixel grid) is still mostly faded out.

**0:22.** Third card (an arcade brick-breaker game) is settling; three layered card edges are visible at the top of the stack. Tagline "Arcade game with pixel-art levels"; the description mentions multi-ball power-ups, combos, a live score and a pause menu. Phone screen: cyan pixel-art brick wall with an arrow shape and a ball at the bottom. A fourth, lighter card is overlapping from above in mid-animation.

**0:24.** Fourth card "Dice": red dice icon, label "IOS APP · UTILITY", title "Dice", tagline "A colourful dice roller", short description, tag pills "Utility", "Minimal UI", "Tap to roll", and a caption "● Screen recording on iPhone". Phone on the left, tilted in 3D, showing colour blocks (blue with 3 dots, red, green) and a "TOTAL 10" chip. The cursor is over "Back to the doors" (hand pointer); the browser status bar shows `https://therishithakor.com/#works`.

**0:26.** Phone screen now shows 4 coloured blocks (blue, red, green, yellow), TOTAL 15. "Back to the doors" is in its hover state: darker pill, arrow nudged left.

**0:28.** Phone shows 2 blocks (blue, red), TOTAL 6. Same hover state.

**0:29.5 to 0:31.** Click: the Dice page ghosts out to white, then the viewport is blank off-white.

**0:32.** Back on the hall of doors (reference): navy WEB DEVELOPER, green UI/UX DESIGNER and orange GRAPHIC DESIGNER closed; the APP DEVELOPER door is swinging open with white light (the reverse of the entry animation).

*(About 0:33 the recording cuts to my own site.)*

---

## Part B: My site (Arghya's portfolio)

**0:34.** Hero inside a big rounded container. Same header: "≡ MENU" pill left, "Local time 11:19am · 8 November, 2026" pill right. Eyebrow "● Independent Freelancer". Headline "Hi, I'm Arghya." in black, then "I am a" on the next line in mid-grey. Under it is a flip-calendar / spiral-notebook card (metal spiral rings along the top, slightly tilted in 3D, black offset shadow block behind it) showing **"Web Developer"** with a page counter "01 / 03". Buttons: black pill "Hire me →" (with a white circular arrow chip) and an outlined pill "See my work". A floating dark-grey pill "My ability card" sits at the right-centre. The right half of the hero is otherwise empty, apart from a small brown round shape clipped at the far right edge.

**0:35.** Same screen; the cursor is on the notebook card.

**0:36.** Scrolled a little. The notebook now shows **"UI/UX Designer"**, counter "02 / 03" (it flips between roles). At the bottom of the hero container, under a hairline: "AVAILABLE FOR WORK" (left), "REMOTE-FIRST, WORLDWIDE" (centre), "SCROLL TO EXPLORE ↓" (right). The container has a large rounded bottom-left corner and a shadow. Below it: heading "Magic happens behind the doors".

**0:37 to 0:38.** Scrolled to the doors. Four doors:
1. navy, plate **"AUCTIONVERSE"**, with a small card printed directly on the door face: a "FEATURED PROJECT" pill, "AuctionVerse", "Sports Auction & Private Leagues", and a white pill "Enter & Visit auctionverse.in ↗" (the text is tiny, roughly 7 to 9 px, and hard to read);
2. plum, plate **"SMART DAY PLANNER"**;
3. dark green, standing open at idle (white doorway); its plate is too small and angled to read;
4. rust orange, plate **"BUSINESS WEBSITES"**.

A near-black section with a rounded top-left corner starts at about y = 393 of the 604 px viewport and covers the bottom of the doors, so the lower ~40 px of the doors, the baseboard and the floor are cut off. That section has the green-dot label "AVAILABLE FOR NEW WORK" and a giant heading "Need something built?" (cut off at the bottom of the screen). Light scroll-to-top button at the bottom right.

**0:40 to 0:42.** Static; nothing changes. The cursor rests at the lower left. The recording ends. No door hover, door click, project page, cookie banner or menu is shown for my site.

---

## Differences between the reference and my site

1. **The dark footer overlaps the doors.** On my site the doors are cut off at the bottom and there is no baseboard or floor before the footer. In the reference the door bottoms, baseboard and peach floor glow are fully visible before the next section starts.
2. **Doors mean different things.** Reference: each door is a *service* (Web, App, UI/UX, Graphic). Hovering opens it and shows a side panel with a checklist and a "Click to enter" cursor label while the other doors dim; clicking leads to a category page with stacked project cards. Mine: each door is a single *project or offer* (AuctionVerse, Smart Day Planner, ?, Business Websites), and the AuctionVerse door has a tiny card printed on its face.
3. **Transitions and inner pages.** The reference zooms through the door, fades to white, then shows a category page with a "Back to the doors" header and the cards stacking on scroll. None of this is visible for my site, so I cannot confirm whether it exists.
4. **Things the reference has that mine does not show:** the hover panel and "Click to enter" cursor label, the dimming of non-hovered doors, the stacked sticky project cards with device mockups playing screen recordings, the analytics cookie banner, the scroll-to-top button with a progress ring on inner pages, and a "My story" section plus floor gradient between the doors and the footer.
5. **Not sure.** The right half of my hero is empty. I never saw the reference's hero, so I cannot say whether that is intended. The open green door at idle matches the reference's behaviour (one door stays ajar until you hover another), so that is probably fine.

---

## What to build or fix (brief for another AI)

- Give the doors section enough bottom padding (or remove the footer's negative margin or overlap) so the full door height, the baseboard and the floor gradient show above the dark footer. Only the footer's rounded corner should overlap the floor, never the doors.
- Decide what a door means. To match the reference: doors = services; hovering shows a side panel (title, mono subtitle, 4 to 5 checklist items) and a "Click to enter" cursor label, and non-hovered doors dim. Move the AuctionVerse mini card off the door face into the hover panel or the destination page. Keep only the brass nameplate and hardware on the door.
- Door interaction: 3D swing using `perspective` with `rotateY` and `transform-origin` on the hinge side, a bright white "doorway" layer behind the door, and one door idling slightly open until another is hovered.
- Page transition: scale up from the clicked door's centre, fade to white, then route to the category page; reverse it for "Back to the doors".
- Category page: large rounded container, fixed header with "Back to the doors" and "Menu" pills, big H1, intro line, then project cards using `position: sticky` with increasing z-index. As the next card slides over, scale the previous one slightly (about 0.95) and darken it (Framer Motion `useScroll` / `useTransform`, or CSS scroll-driven animations). Alternate the layout (phone left or right). Put device mockups with looping screen recordings inside the cards.
- Add the circular scroll-to-top button with a progress ring (an SVG circle with `stroke-dashoffset` tied to scroll progress) and an optional analytics consent banner.
- Use my own wording and illustrations. Several phrases (for example "Magic happens behind the doors" and "Back to the doors") and the door artwork are very close to the original site's.
