# What changed (your project: portfolio-studio)

Unzip, then copy the contents of `portfolio-studio/` over your project folder (it keeps your folder layout).
Run `npm run dev` to test and `npm run build` before you deploy (your old `dist/` is out of date).

## Files changed
- `index.html` (hallway)
- `public/web-developer/index.html` (Web Developer room)

## index.html
1. Footer green "available" dot: animated box-shadow forever, repainting the whole footer every frame. Now a transform/opacity ring (same look). Idle main-thread work dropped about 10x.
2. Doors not reacting: the hidden hover panel blocked the mouse over neighbouring doors. It now lets the mouse through (only its buttons take clicks).
3. Door swing speed depended on screen refresh rate (fixed 1/60 step). Now uses real elapsed time.
4. Door hover repaint cost: swing writes opacity directly (no per-frame custom property), box-shadow transitions replaced with fading shadow layers (.door::before, .castsh), scroll hover check runs once per frame.
5. Cord: cached the per-frame style read (shadow blur kept as you had it).
6. Door 1 hover panel text now: FEATURED: AUCTIONVERSE · SMART DAY PLANNER.

## public/web-developer/index.html
- Added Smart Day Planner as a second card (copied from the App room; it is still there too).
- Cards pop in (when the door opens / when scrolled to) and stack: the covered card shrinks and dims as the next slides over it.
- Tall cards pin by their bottom edge so nothing is unreachable.

## extras/
- `portfolio-preview.html`: everything in ONE file (fonts, images and all four rooms inline) for previewing or sharing. Not for development.
- `portfolio-video-description.md`: frame-by-frame description of your screen recording, for other AI models.

## Not changed / notes
- Smooth scroll (Lenis) never loads: the import map points to a missing `lenis.min.mjs`. Harmless.
- The room "Enter Room" button in the hover panel is hard to reach with the mouse (it sits under a neighbouring door).
